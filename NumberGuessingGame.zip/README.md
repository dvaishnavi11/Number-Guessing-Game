# Number Guessing Game 🎲

A simple Python game where you guess a random number between 1 and 100.

## How to Run:
1. Install Python 3
2. Run the script:
   ```bash
   python guess_game.py
   ```
Enjoy the game!
